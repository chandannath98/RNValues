/* eslint-disable prettier/prettier */
/* eslint-disable no-unreachable */
/* eslint-disable prettier/prettier */
const INITIAL_STATE = {
    stateData: {},
  };

  export default function productSub(state = INITIAL_STATE, action) {
  // console.log('customerfilterData=====>', action);
    switch (action.type) {
          case 'PRODUCT_LIST':
            return {
              ...state,
              ProductData:action.ProductData,
            };
            break;
            case 'PRODUCT_DROPLIST':
              return {
                ...state,
                ProductdropData:action.ProductdropData,
              };
              break;
            case 'PRODUCT_DETAILS_LIST':
            return {
              ...state,
              ProductDetailsData:action.ProductDetailsData,
            };
            break;
            case 'PRODUCT_DETAILS_DROP_LIST':
              return {
                ...state,
                ProductDetailsData:action.ProductDetailsData,
              };
              break;
              case 'PRODUCT_DROPDOWN_LIST':
                return {
                  ...state,
                  productdropdownListData:action.productdropdownListData,
                };
                break;
                case 'CREATE_PRODUCT_SUCCESS':
                return {
                  ...state,
                  ProductcreateData:action.ProductcreateData,
                };
                break;
                case 'CREATE_NEW_PRODUCT_SUCCESS':
                return {
                  ...state,
                  ProductcreatenewData:action.ProductcreatenewData,
                };
                break;
                case 'ESTIMATE_LIST_ORDER':
                return {
                  ...state,
                  estimatelistorderData:action.estimatelistorderData,
                };
                break;
                case 'ORDER_LIST':
                return {
                  ...state,
                  OrderListData:action.OrderListData,
                };
                break;
            
      default:
        return state;
    }
  }
  