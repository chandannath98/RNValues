/* eslint-disable prettier/prettier */
const url = {
    Logo: require('../assests/images/logo.png'),
    Eye: require('../assests/images/visibility.png'),
    OpenEye: require('../assests/images/open-visibility.png'),
    Play: require('../assests/images/play.png'),
    DrawerIcon:'https://bootdey.com/img/Content/avatar/avatar6.png',
    img:'https://bootdey.com/img/Content/avatar/avatar5.png',

  };
  export default url;
