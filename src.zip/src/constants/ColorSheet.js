/* eslint-disable prettier/prettier */
export const Color = {
  white: '#fff',
  TEXT_COLOR: '#616161',
  INPUT_TEXT_BORDER: '#dadce0',
  RED_COLOR: '#d42a1e',
  RED_LIGHT: '#ff1100',
  BUTTON_COLOR: '#E87511',
};
