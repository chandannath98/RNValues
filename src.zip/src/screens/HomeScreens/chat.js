import * as React from 'react';
import { View, Text } from 'react-native';


function Chat() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Chat Screen</Text>
    </View>
  );
}



export default Chat;