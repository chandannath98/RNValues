import * as React from 'react';
import { View, Text } from 'react-native';


function Target() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>Target Screen</Text>
    </View>
  );
}



export default Target;