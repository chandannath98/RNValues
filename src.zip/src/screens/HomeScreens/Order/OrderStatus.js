import React, {useEffect} from 'react';
import {
  View,
  Text,
  ImageBackground,
  Image,
  TouchableOpacity,
  FlatList
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useSelector, useDispatch} from 'react-redux';
import * as actions from '../../../redux/actions/authaction';
import Loader from '../../../utils/Loader';
import {useNavigation} from '@react-navigation/native';
const OrderStatus = props => {
  const navigation = useNavigation();

  const loginData = useSelector(state => state.auth.loginData);
  const isLoading = useSelector(state => state.loader.isLoading);

  const dispatch = useDispatch();
  const handleDealerList = data =>
    dispatch(actions.handleDealerList({data, navigation}));
  // const handleMyCustomer = data => dispatch(actions.handleMyCustomer({ data, navigation }));

  const OrderListData = useSelector(state => state.productSub.OrderListData);

  console.log('====================================');
  console.log(OrderListData);
  console.log('====================================');

  const findthedata = () => {
    if (props.name == 1) {
      console.log(1);
      const data = {
        ID: 1,
        type: 'salesmen',
        customer: 1,
      };
      handleDealerList(data);
    } else if (props.name == 2) {
      console.log(2);
      const data = {
        type: loginData.data.model,
        ID: loginData.data.ID,
        customer: 1,
      };
      handleDealerList(data);
    } else {
      console.log(3);
      const data = {
        role: loginData.data.Role,
        ID: loginData.data.ID,
        customer: 3,
      };
      handleDealerList(data);
    }
  };

  return (
    <View style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={isLoading} />
      <ImageBackground
        style={{height: 60, width: '100%'}}
        source={require('../../../assests/Dashboard/UserloginBG.png')}>
        <View style={{height: 60, width: '100%', flexDirection: 'row'}}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{
              width: '15%',
              height: 60,
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Image
              source={require('../../../assests/Dashboard/arrowwhite.png')}
            />
          </TouchableOpacity>
          <View style={{width: '55%', height: 60, justifyContent: 'center'}}>
            <Text
              style={{
                fontSize: 17,
                fontWeight: '400',
                color: '#fff',
                marginLeft: 15,
              }}>
              Order
            </Text>
          </View>
        </View>
      </ImageBackground>
      <View style={{flex: 1, alignItems: 'center', paddingVertical: 10}}>
        {OrderListData?.data ? (
          <View
            style={{
              width: '100%',
              height: '100%',
              alignItems: 'center',
            }}>
              <FlatList
              data={OrderListData?.data}
              numColumns={1}
              //  keyExtractor={item => item.ID.toString()}
              // ItemSeparatorComponent={() => Separator()}
              renderItem={({item}) => (
                <TouchableOpacity
                  //onPress={() => navigation.navigate("CheckIn",{itemId:item.ID})}
                >
                  <View
                    style={{
                      height: 90,
                      width: '100%',
                      backgroundColor: '#fff',
                      elevation: 2,
                      flexDirection: 'row',
                      marginTop: 10,
                    }}>
                    <View
                      style={{
                        height: 90,
                        width: '20%',
                        backgroundColor: '#fff',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}>
                      <Image source={require('../../../assests/map.png')} />
                    </View>
                    <View
                      style={{
                        height: 90,
                        width: '55%',
                        justifyContent: 'center',
                      }}>
                      <Text
                        numberOfLines={1}
                        style={{
                          color: '#303231',
                          fontSize: 16,
                          fontWeight: '500',
                        }}>
                        {
                        item.Company.length < 18 ?
                        item.Company.substring(0, 18):
                        item.Company.substring(0, 18)+".."
                        }
                      </Text>
                      <Text
                        style={{
                          color: '#BDBDBD',
                          fontSize: 12,
                          fontWeight: '500',
                        }}>
                        GST NO- {item.CustomerGST}
                      </Text>
                      <Text
                        style={{
                          color: '#00A9FF',
                          fontSize: 12,
                          fontWeight: '500',
                          textDecorationLine: 'underline',
                        }}>
                        {item.EstimaterPhone}
                      </Text>
                    </View>
                    <View
                      style={{
                        height: 90,
                        width: '25%',
                        justifyContent: 'space-around',
                      }}>
                      <Text
                        numberOfLines={1}
                        style={{
                          color: '#BDBDBD',
                          fontSize: 12,
                          fontWeight: '500',
                        }}>
                        {item.CreatedAt}
                      </Text>
                      <Text
                        style={{
                          color: '#000000',
                          fontSize: 15,
                          fontWeight: '600',
                        }}>
                        ₹ {item.GrandTotal}
                      </Text>
                    </View>
                  </View>
                  <View
                    style={{
                      height: 50,
                      width: '100%',
                      elevation: 4,
                      flexDirection: 'row',
                      backgroundColor: '#fff',
                    }}>
                    <View
                      style={{
                        width: '50%',
                        height: 50,
                        borderRightWidth: 1,
                        borderTopWidth: 1,
                        justifyContent: 'center',
                        borderColor: '#BDBDBD',
                        alignItems:'center'
                      }}>
                      <Text
                        style={{
                          color: '#303231',
                          fontSize: 16,
                          fontWeight: '500',
                          marginLeft: 5,
                        }}>
                          Status
                        {/* CRM ({item.CRMName}) */}
                      </Text>
                    </View>
                    <View
                      style={{
                        width: '50%',
                        height: 50,
                        borderTopWidth: 1,
                        borderColor: '#BDBDBD',
                        alignItems:'center',
                        flexDirection:'row-reverse',
                        paddingHorizontal:10
                     
                      }}>
                      <TouchableOpacity
                     // style={{backgroundColor:'red',justifyContent:'center',alignItems:'center',width:'100%'}}
                        //onPress={() => openDialScreen(item.CRMPhone)}
                        >
                        <Text
                          style={{
                            color: '#00A9FF',
                            fontSize: 12,
                            fontWeight: '500',
                            // textDecorationLine: 'underline',
                            marginRight:25,
                            textTransform: 'uppercase'
                            
                          }}>
                          {item.Status}
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </TouchableOpacity>
              )}
            />
            </View>
        ) : (
          <View
            style={{
              width: '100%',
              height: '100%',
              alignItems: 'center',
            }}>
            <Image
              source={require('../../../assests/Dashboard/leaveBackground.png')}
            />
            <View>
              <Text style={{fontSize: 24, fontWeight: '700'}}>
                No order found
              </Text>
            </View>
          </View>
        )}

        <View
          style={{
            width: '90%',
            height: '100%',
            // backgroundColor:'red',
            flexDirection: 'row-reverse',
            alignItems: 'flex-end',
            position: 'absolute',
          }}>
          <TouchableOpacity
            //onPress={() => navigation.navigate("ChooseDealer")}
            onPress={() => findthedata()}
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              height: 40,
              backgroundColor: '#007DFE',
              paddingHorizontal: 10,
              borderRadius: 20,
              flexDirection: 'row',
            }}>
            <Text
              style={{
                fontSize: 14,
                fontWeight: '700',
                color: '#fff',
                marginRight: 5,
              }}>
              Add Order
            </Text>
            <AntDesign name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default OrderStatus;
